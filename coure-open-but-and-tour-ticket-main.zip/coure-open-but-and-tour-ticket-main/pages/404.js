import React from "react";

const index = () => {
    return <div>NOT FOUND</div>;
};

export default index;
