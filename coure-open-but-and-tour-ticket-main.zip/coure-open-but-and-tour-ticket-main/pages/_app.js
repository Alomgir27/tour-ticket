import NextNProgress from "nextjs-progressbar";
import Layout from "@/components/Layout/Layout";
import { store } from "@/reduxStore/store";
import "@/styles/globals.css";
import { Provider } from "react-redux";
import "swiper/css";

export default function App({ Component, pageProps }) {
    return (
        <Provider store={store}>
            <NextNProgress color="#ef4444" />
            <Layout>
                <Component {...pageProps} />
            </Layout>
        </Provider>
    );
}
