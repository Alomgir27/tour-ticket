import React from "react";
import Header from "./Header";
import Hero from "../Index/Hero";
import { useRouter } from "next/router";
import Footer from "./Footer";

function Layout({ children }) {
    const router = useRouter();
    return (
        // Make header top hero and childrens fill all screen and footer bottom
        <div className="grid grid-rows-[auto,1fr,auto] min-h-screen">
            {router.pathname == "/" && (
                <div className="absolute z-0 w-full h-[810px] bg-gradient-to-b from-orange-50 to-orange-100/0" />
            )}
            <Header />
            {router.pathname == "/" && <Hero />}
            {children}
            <Footer />
        </div>
    );
}

export default Layout;
