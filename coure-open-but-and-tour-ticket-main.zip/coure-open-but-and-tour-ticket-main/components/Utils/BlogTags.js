import React from "react";

function BlogTags({}) {
    return (
        <div className="rounded-2xl flex-col flex group cursor-pointer">
            <div className="text-zinc-800 bg-slate-200 rounded-sm text-sm font-normal px-2 py-1">Tips & Tricks</div>
        </div>
    );
}

export default BlogTags;
