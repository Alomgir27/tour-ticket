<?php

const ROLE_ADMIN = 1;
const ROLE_AGENT = 2;
const ROLE_USER = 3;